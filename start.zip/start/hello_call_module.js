var olleh = require('./hello_user_module.js');

olleh("Node");
olleh("aa24");