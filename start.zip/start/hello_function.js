function hello(what) {
    console.log("Hello " + what + " !");
}

hello("aa24");
hello("Comsi, 김경영");