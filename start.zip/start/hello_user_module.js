module.exports = function(what) {
    console.log("Hello " + what + " !");
}