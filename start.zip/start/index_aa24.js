var myinfo = require('./aa24info.js');

myinfo("aa00", "Redwoods", '010-1234-5678');

myinfo("aa24", "comsi", '010-5678-1234');
